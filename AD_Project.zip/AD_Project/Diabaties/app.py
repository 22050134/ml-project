import pandas as pd
import numpy as np
import os
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from flask import Flask, request, render_template, jsonify

app = Flask(__name__)

# Create models directory if it doesn't exist
os.makedirs('models', exist_ok=True)

# Path to the dataset
dataset_path = r"C:\Users\KIIT\OneDrive\Desktop\Python_AD\AD_Project\Diabaties\diabetes_prediction_dataset.csv"

# Function to train the model and save it
def train_model():
    try:
        # Load the dataset
        df = pd.read_csv("C:/Users/KIIT/OneDrive/Desktop/Python_AD/AD_Project/Diabaties/diabetes_prediction_dataset.csv")        
        # Display basic info about the dataset
        print(f"Dataset loaded successfully with {df.shape[0]} rows and {df.shape[1]} columns")
        print("Columns:", df.columns.tolist())
        
        # Check for missing values
        missing_values = df.isnull().sum()
        print("Missing values:\n", missing_values)
        
        # Handle any missing values if needed
        df = df.dropna()
        
        # Assuming the target column is named 'diabetes' or similar
        # You may need to adjust this based on your actual dataset
        if 'diabetes' in df.columns:
            target_column = 'diabetes'
        elif 'Diabetes' in df.columns:
            target_column = 'Diabetes'
        elif 'diabetes_mellitus' in df.columns:
            target_column = 'diabetes_mellitus'
        else:
            # Make an educated guess - last column might be the target
            target_column = df.columns[-1]
            print(f"Target column not explicitly identified, using {target_column} as target")
        
        # Prepare features and target
        X = df.drop(target_column, axis=1)
        
        # Handle categorical features - convert to numerical
        X = pd.get_dummies(X, drop_first=True)
        
        y = df[target_column]
        
        # Split data for training and testing
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        
        # Train the Random Forest model
        rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
        rf_model.fit(X_train, y_train)
        
        # Evaluate the model
        y_pred = rf_model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print(f"Model accuracy: {accuracy:.4f}")
        print("Classification Report:")
        print(classification_report(y_test, y_pred))
        
        # Save the model
        model_path = 'models/random_forest.pkl'
        with open(model_path, 'wb') as file:
            pickle.dump(rf_model, file)
        
        # Save the feature columns for later use
        feature_cols = X.columns.tolist()
        with open('models/feature_columns.pkl', 'wb') as file:
            pickle.dump(feature_cols, file)
            
        print(f"Model saved successfully at {model_path}")
        return True
    
    except Exception as e:
        print(f"Error training model: {str(e)}")
        return False

# Function to load the model
def load_model():
    try:
        with open('models/random_forest.pkl', 'rb') as file:
            model = pickle.load(file)
        
        with open('models/feature_columns.pkl', 'rb') as file:
            feature_cols = pickle.load(file)
        
        return model, feature_cols
    
    except FileNotFoundError:
        print("Model files not found. Training the model first...")
        if train_model():
            return load_model()
        else:
            return None, None
    
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        return None, None

# Load or train the model when the app starts
model, feature_columns = load_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        if request.is_json:
            # For API requests
            data = request.get_json()
            
            # Create a DataFrame with the required features
            input_df = pd.DataFrame([data])
            
            # Handle categorical features with one-hot encoding
            input_df = pd.get_dummies(input_df)
            
            # Ensure input has all needed columns that model was trained on
            for col in feature_columns:
                if col not in input_df.columns:
                    input_df[col] = 0
            
            # Keep only the columns the model was trained on
            input_df = input_df[feature_columns]
            
            # Make prediction
            prediction = model.predict(input_df)
            prediction_proba = model.predict_proba(input_df)
            
            result = {
                'prediction': int(prediction[0]),
                'probability': float(prediction_proba[0][1])
            }
            
            return jsonify(result)
        
        else:
            # For web form submissions
            # Extract form fields - adjust based on your dataset's features
            gender = request.form.get('gender')
            age = float(request.form.get('age'))
            hypertension = int(request.form.get('hypertension'))
            heart_disease = int(request.form.get('heart_disease'))
            smoking_history = request.form.get('smoking_history')
            bmi = float(request.form.get('bmi'))
            HbA1c_level = float(request.form.get('HbA1c_level'))
            blood_glucose_level = float(request.form.get('blood_glucose_level'))
            
            # Create a dictionary with input values
            input_data = {
                'gender': gender,
                'age': age,
                'hypertension': hypertension,
                'heart_disease': heart_disease,
                'smoking_history': smoking_history,
                'bmi': bmi,
                'HbA1c_level': HbA1c_level,
                'blood_glucose_level': blood_glucose_level
            }
            
            # Create DataFrame with input data
            input_df = pd.DataFrame([input_data])
            
            # One-hot encode categorical features
            input_df = pd.get_dummies(input_df)
            
            # Ensure input has all needed columns
            for col in feature_columns:
                if col not in input_df.columns:
                    input_df[col] = 0
                    
            # Keep only the columns the model was trained on
            input_df = input_df[feature_columns]
            
            # Make prediction
            prediction = model.predict(input_df)
            prediction_proba = model.predict_proba(input_df)
            
            result = {
                'prediction': 'Diabetic' if prediction[0] == 1 else 'Non-Diabetic',
                'probability': round(prediction_proba[0][1] * 100, 2)
            }
            
            return render_template('result.html', result=result)
    
    except Exception as e:
        return jsonify({'error': str(e)})

# Add a route to handle model retraining
@app.route('/retrain', methods=['GET'])
def retrain():
    if train_model():
        global model, feature_columns
        model, feature_columns = load_model()
        return jsonify({'status': 'success', 'message': 'Model retrained successfully'})
    else:
        return jsonify({'status': 'error', 'message': 'Failed to retrain model'})

if __name__ == '__main__':
    if model is None:
        print("Failed to load or train the model. Please check the paths and dataset.")
    app.run(debug=True)